# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow_clinet.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(558, 592)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        #textBrowser
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(10, 160, 541, 291))
        self.textBrowser.setObjectName("textBrowser")
        #lineEdit_Mesage
        self.lineEdit_Mesage = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_Mesage.setGeometry(QtCore.QRect(10, 460, 541, 31))
        self.lineEdit_Mesage.setObjectName("lineEdit_Mesage")
        #PushButton_Send
        self.PushButton_Send = QtWidgets.QPushButton(self.centralwidget)
        self.PushButton_Send.setGeometry(QtCore.QRect(10, 500, 541, 41))
        self.PushButton_Send.setObjectName("PushButton_Send")


        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 558, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        #self.PushButton_Login.clicked.connect(self.login)



    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.PushButton_Send.setText(_translate("MainWindow", "Send"))


