# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow_clinet.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(558, 592)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        #label_N
        self.label_N = QtWidgets.QLabel(self.centralwidget)
        self.label_N.setGeometry(QtCore.QRect(10, 10, 80, 50))
        self.label_N.setObjectName("label_N")
        # label:NickName
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(60, 60, 81, 41))
        self.label.setObjectName("label")
        # lineEdit_Name
        self.lineEdit_Name = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_Name.setGeometry(QtCore.QRect(180, 60, 271, 41))
        self.lineEdit_Name.setObjectName("lineEdit_Name")
        # label_P:Password
        self.label_P = QtWidgets.QLabel(self.centralwidget)
        self.label_P.setGeometry(QtCore.QRect(60, 180, 81, 41))
        self.label_P.setObjectName("label_P")
        # lineEdit_Password
        self.lineEdit_Password = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_Password.setGeometry(QtCore.QRect(180, 180, 271, 41))
        self.lineEdit_Password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_Password.setObjectName("lineEdit_Password")

        # PushButton_Register
        self.PushButton_Register = QtWidgets.QPushButton(self.centralwidget)
        self.PushButton_Register.setGeometry(QtCore.QRect(60, 400, 150, 50))
        self.PushButton_Register.setObjectName("PushButton_Register")

        #PushButton_Login
        self.PushButton_Login = QtWidgets.QPushButton(self.centralwidget)
        self.PushButton_Login.setGeometry(QtCore.QRect(350, 400, 150, 50))
        self.PushButton_Login.setObjectName("PushButton_Login")

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 558, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.PushButton_Login.clicked.connect(self.login)

    def login(self):
        self.PushButton_Login.setEnabled(False)
        self.lineEdit_Name.setEnabled(False)
        self.lineEdit_Password.setEnabled(False)


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "NickName"))
        self.label_P.setText(_translate("MainWindow", "Password"))
        self.label_N.setText(_translate("MainWindow", "營養助理師"))
        self.PushButton_Login.setText(_translate("MainWindow", "Login"))
        self.PushButton_Register.setText(_translate("MainWindow", "Register"))

