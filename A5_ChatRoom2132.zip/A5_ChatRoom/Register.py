from PyQt5.QtWidgets import QMainWindow, QApplication
import Register_ui
import sys
import socket
import threading

class Client(QMainWindow, Register_ui.Ui_MainWindow):
    def __init__(self, host, port):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock = sock
        self.sock.connect((host, port))
        self.sock.send(b'1')
        self.nickname = None
        self.password = None
        self.PushButton_Login.clicked.connect(self.login)#22
        #self.PushButton_Register.click(self.register)


    def login(self):#11
        self.nickname = self.lineEdit_Name.text()#222
        self.password = self.lineEdit_Password.text()
        message = '#NAME#,{nickname},#PASSWORD#,{password}'.format(nickname=self.nickname, password=self.password)
        self.sock.send(message.encode())

    """def register(self):#11
        self.nickname = self.lineEdit_Name.text()#222
        self.password = self.lineEdit_Password.text()
        message = '#REG#,{nickname},#REGWORD#,{password}'.format(nickname=self.nickname, password=self.password)
        self.sock.send(message.encode())"""

if __name__ == "__main__":
    app = QApplication(sys.argv)
    MainWindow = Client('localhost', 5555)
    MainWindow.show()
    sys.exit(app.exec_())

